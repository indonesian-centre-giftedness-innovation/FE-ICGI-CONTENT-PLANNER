import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { ProtectedRoute } from "./routes/ProtectedRoute";
import { LoginPage } from "./pages/LoginPage";
import { DashboardPage } from "./pages/DashboardPage";
import { PlaceholderPage } from "./pages/PlaceholderPage";
import { ContentNewPage } from "./pages/ContentNewPage";
import { ContentEditPage } from "./pages/ContentEditPage";
import { StoryboardPage } from "./pages/StoryboardPage";
import { CalendarTodoPage } from "./pages/CalendarTodoPage";
import { ApprovalQueuePage } from "./pages/ApprovalQueuePage";
import { NotificationsPage } from "./pages/NotificationsPage";
import { MediaReviewPage } from "./pages/MediaReviewPage";
import { StoryboardListPage } from "./pages/StoryboardListPage";
import { MediaListPage } from "./pages/MediaListPage";

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/login" element={<LoginPage />} />

          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DashboardPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/content/new"
            element={
              <ProtectedRoute>
                <ContentNewPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/content/:id/edit"
            element={
              <ProtectedRoute>
                <ContentEditPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/content/:id/storyboard"
            element={
              <ProtectedRoute>
                <StoryboardPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/content/:id/calendar"
            element={
              <ProtectedRoute>
                <CalendarTodoPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/content/:id/media"
            element={
              <ProtectedRoute>
                <MediaReviewPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/storyboard"
            element={
              <ProtectedRoute>
                <StoryboardListPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/media"
            element={
              <ProtectedRoute>
                <MediaListPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/approval"
            element={
              <ProtectedRoute requireRole="lead_admin">
                <ApprovalQueuePage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/notifications"
            element={
              <ProtectedRoute>
                <NotificationsPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/prompt-templates"
            element={
              <ProtectedRoute requireRole="lead_admin">
                <PlaceholderPage title="Prompt templates" />
              </ProtectedRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}