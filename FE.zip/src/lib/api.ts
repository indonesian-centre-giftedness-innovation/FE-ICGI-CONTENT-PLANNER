const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || `Request gagal (${res.status})`);
  }

  return res.json();
}

// khusus upload file — JANGAN set Content-Type manual, biarkan browser
// yang menentukan boundary multipart/form-data secara otomatis
async function requestFormData<T>(path: string, formData: FormData): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: "POST",
    credentials: "include",
    body: formData,
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || `Upload gagal (${res.status})`);
  }

  return res.json();
}

/** URL langsung untuk preview/download file (dipakai di tag <img>/<video>/<a>) */
export function mediaFileUrl(versionId: string): string {
  return `${BASE_URL}/media/versions/${versionId}/file`;
}

export type ContentStatus =
  | "draft"
  | "pending_review"
  | "revisi"
  | "approved"
  | "published";

export type Content = {
  id: string;
  title: string;
  bodyDraft: string | null;
  bodyAiGenerated: string | null;
  status: ContentStatus;
  requiresApproval: boolean;
  platform: string | null;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  author?: { id: string; name: string; role: string };
};

export type StoryboardScene = {
  id: string;
  storyboardId: string;
  sceneOrder: number;
  sketchImageGdriveId: string | null;
  description: string | null;
  durationSeconds: number;
  createdAt: string;
};

export type Storyboard = {
  id: string;
  contentId: string;
  title: string | null;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
  scenes: StoryboardScene[];
};

export type CalendarItem = {
  id: string;
  contentId: string;
  scheduledDate: string;
  platform: string | null;
  createdAt: string;
  content?: { id: string; title: string; status: ContentStatus };
};

export type Todo = {
  id: string;
  contentId: string;
  taskText: string;
  isDone: boolean;
  assignedTo: string | null;
  createdAt: string;
  assignee?: { id: string; name: string } | null;
};

export type SimpleUser = {
  id: string;
  name: string;
  role: "lead_admin" | "creator_staff";
};

export type Approval = {
  id: string;
  contentId: string;
  reviewerId: string;
  status: "approved" | "revisi";
  notes: string | null;
  reviewedAt: string;
  reviewer?: { id: string; name: string };
};

export type AppNotification = {
  id: string;
  userId: string;
  type: "approval" | "revisi" | "comment" | "media_approved";
  contentId: string | null;
  message: string;
  isRead: boolean;
  createdAt: string;
  content?: { id: string; title: string } | null;
};

export type MediaComment = {
  id: string;
  mediaVersionId: string;
  userId: string;
  commentText: string;
  timestampSeconds: number | null;
  positionX: number | null;
  positionY: number | null;
  isResolved: boolean;
  parentCommentId: string | null;
  createdAt: string;
  user?: { id: string; name: string };
};

export type MediaVersion = {
  id: string;
  mediaAssetId: string;
  versionNumber: number;
  gdriveFileId: string;
  status: "pending" | "approved";
  uploadedBy: string | null;
  createdAt: string;
  deletedAt: string | null;
};

export type MediaAsset = {
  id: string;
  contentId: string;
  fileName: string;
  mimeType: string | null;
  uploadedBy: string | null;
  createdAt: string;
  versions: MediaVersion[];
};

export type StoryboardSummary = {
  id: string;
  contentId: string;
  title: string | null;
  updatedAt: string;
  content: { id: string; title: string; status: ContentStatus; platform: string | null } | null;
  sceneCount: number;
  totalDurationSeconds: number;
};

export type MediaAssetSummary = {
  id: string;
  contentId: string;
  fileName: string;
  mimeType: string | null;
  createdAt: string;
  content: { id: string; title: string; status: ContentStatus; platform: string | null } | null;
  latestVersion: MediaVersion | null;
  versionCount: number;
};

export const api = {
  login: (email: string, password: string) =>
    request<{ id: string; name: string; role: string }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
  logout: () => request("/auth/logout", { method: "POST" }),
  me: () => request<{ userId: string; role: string }>("/auth/me"),

  // --- content CRUD ---
  listContents: (params?: { status?: string; search?: string }) => {
    const qs = new URLSearchParams();
    if (params?.status) qs.set("status", params.status);
    if (params?.search) qs.set("search", params.search);
    const suffix = qs.toString() ? `?${qs.toString()}` : "";
    return request<Content[]>(`/content${suffix}`);
  },
  getContent: (id: string) => request<Content>(`/content/${id}`),
  createContent: (data: { title: string; bodyDraft?: string; platform?: string }) =>
    request<Content>("/content", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateContent: (
    id: string,
    data: Partial<Pick<Content, "title" | "bodyDraft" | "platform" | "status">>
  ) =>
    request<Content>(`/content/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
  deleteContent: (id: string) =>
    request<{ message: string }>(`/content/${id}`, { method: "DELETE" }),

  // --- storyboard CRUD ---
  listAllStoryboards: () => request<StoryboardSummary[]>("/storyboard"),
  getStoryboardByContent: (contentId: string) =>
    request<Storyboard | null>(`/storyboard/content/${contentId}`),
  createStoryboard: (contentId: string, title?: string) =>
    request<Storyboard>("/storyboard", {
      method: "POST",
      body: JSON.stringify({ contentId, title }),
    }),
  addScene: (
    storyboardId: string,
    data: { description?: string; durationSeconds?: number; sketchImageGdriveId?: string }
  ) =>
    request<StoryboardScene>(`/storyboard/${storyboardId}/scenes`, {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateScene: (
    sceneId: string,
    data: Partial<Pick<StoryboardScene, "description" | "durationSeconds" | "sketchImageGdriveId">>
  ) =>
    request<StoryboardScene>(`/storyboard/scenes/${sceneId}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
  moveScene: (sceneId: string, direction: "up" | "down") =>
    request(`/storyboard/scenes/${sceneId}/move`, {
      method: "PATCH",
      body: JSON.stringify({ direction }),
    }),
  deleteScene: (sceneId: string) =>
    request<{ message: string }>(`/storyboard/scenes/${sceneId}`, { method: "DELETE" }),

  // --- calendar CRUD ---
  listCalendarItems: () => request<CalendarItem[]>("/calendar"),
  listCalendarItemsForContent: (contentId: string) =>
    request<CalendarItem[]>(`/calendar/content/${contentId}`),
  createCalendarItem: (data: { contentId: string; scheduledDate: string; platform?: string }) =>
    request<CalendarItem>("/calendar", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateCalendarItem: (id: string, data: { scheduledDate?: string; platform?: string }) =>
    request<CalendarItem>(`/calendar/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
  deleteCalendarItem: (id: string) =>
    request<{ message: string }>(`/calendar/${id}`, { method: "DELETE" }),

  // --- todo CRUD ---
  listTodosForContent: (contentId: string) =>
    request<Todo[]>(`/todos/content/${contentId}`),
  createTodo: (data: { contentId: string; taskText: string; assignedTo?: string }) =>
    request<Todo>("/todos", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateTodo: (
    id: string,
    data: Partial<{ taskText: string; isDone: boolean; assignedTo: string }>
  ) =>
    request<Todo>(`/todos/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
  deleteTodo: (id: string) =>
    request<{ message: string }>(`/todos/${id}`, { method: "DELETE" }),

  // --- users ---
  listUsers: () => request<SimpleUser[]>("/users"),

  // --- approval flow ---
  submitForReview: (contentId: string) =>
    request<Content>(`/approval/${contentId}/submit`, { method: "POST" }),
  listPendingApprovals: () => request<Content[]>("/approval/pending"),
  getApprovalHistory: (contentId: string) =>
    request<Approval[]>(`/approval/content/${contentId}`),
  approveContent: (contentId: string, notes?: string) =>
    request<Content>(`/approval/${contentId}/approve`, {
      method: "POST",
      body: JSON.stringify({ notes }),
    }),
  requestRevision: (contentId: string, notes: string) =>
    request<Content>(`/approval/${contentId}/revisi`, {
      method: "POST",
      body: JSON.stringify({ notes }),
    }),
  publishContent: (contentId: string) =>
    request<Content>(`/approval/${contentId}/publish`, { method: "POST" }),

  // --- notifications ---
  listNotifications: () => request<AppNotification[]>("/notifications"),
  markNotificationRead: (id: string) =>
    request<AppNotification>(`/notifications/${id}/read`, { method: "PATCH" }),
  markAllNotificationsRead: () =>
    request<{ message: string }>("/notifications/read-all", { method: "PATCH" }),

  // --- media upload & review ---
  listAllMedia: () => request<MediaAssetSummary[]>("/media"),
  listMediaForContent: (contentId: string) =>
    request<MediaAsset[]>(`/media/content/${contentId}`),
  uploadNewMedia: (contentId: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return requestFormData<MediaAsset>(`/media/content/${contentId}`, fd);
  },
  uploadMediaVersion: (assetId: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return requestFormData<MediaVersion>(`/media/${assetId}/versions`, fd);
  },
  deleteMediaAsset: (assetId: string) =>
    request<{ message: string }>(`/media/${assetId}`, { method: "DELETE" }),
  approveMediaVersion: (versionId: string) =>
    request<MediaVersion>(`/media/versions/${versionId}/approve`, { method: "POST" }),
  listMediaComments: (versionId: string) =>
    request<MediaComment[]>(`/media/versions/${versionId}/comments`),
  addMediaComment: (
    versionId: string,
    data: {
      commentText: string;
      timestampSeconds?: number;
      positionX?: number;
      positionY?: number;
      parentCommentId?: string;
    }
  ) =>
    request<MediaComment>(`/media/versions/${versionId}/comments`, {
      method: "POST",
      body: JSON.stringify(data),
    }),
  resolveMediaComment: (commentId: string, isResolved = true) =>
    request<MediaComment>(`/media/comments/${commentId}/resolve`, {
      method: "PATCH",
      body: JSON.stringify({ isResolved }),
    }),
  deleteMediaComment: (commentId: string) =>
    request<{ message: string }>(`/media/comments/${commentId}`, { method: "DELETE" }),
};