import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api, type Storyboard } from "../lib/api";

export function StoryboardPage() {
  const { id: contentId } = useParams<{ id: string }>();

  const [storyboard, setStoryboard] = useState<Storyboard | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [description, setDescription] = useState("");
  const [duration, setDuration] = useState("3");
  const [isAdding, setIsAdding] = useState(false);

  async function load() {
    if (!contentId) return;
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.getStoryboardByContent(contentId);
      setStoryboard(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal memuat storyboard");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contentId]);

  async function handleCreateStoryboard() {
    if (!contentId) return;
    try {
      const created = await api.createStoryboard(contentId);
      setStoryboard({ ...created, scenes: [] });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal membuat storyboard");
    }
  }

  async function handleAddScene(e: React.FormEvent) {
    e.preventDefault();
    if (!storyboard) return;
    setIsAdding(true);
    setError(null);
    try {
      await api.addScene(storyboard.id, {
        description: description.trim() || undefined,
        durationSeconds: Number(duration) || 0,
      });
      setDescription("");
      setDuration("3");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal menambah scene");
    } finally {
      setIsAdding(false);
    }
  }

  async function handleUpdateScene(sceneId: string, field: "description" | "durationSeconds", value: string) {
    try {
      await api.updateScene(sceneId, {
        [field]: field === "durationSeconds" ? Number(value) || 0 : value,
      } as any);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal menyimpan perubahan scene");
    }
  }

  async function handleMove(sceneId: string, direction: "up" | "down") {
    try {
      await api.moveScene(sceneId, direction);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal mengubah urutan");
    }
  }

  async function handleDeleteScene(sceneId: string) {
    if (!confirm("Hapus scene ini?")) return;
    try {
      await api.deleteScene(sceneId);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal menghapus scene");
    }
  }

  if (isLoading) return <p className="text-muted">Memuat...</p>;

  const totalDuration = storyboard?.scenes.reduce((sum, s) => sum + s.durationSeconds, 0) ?? 0;

  return (
    <div style={{ maxWidth: 760 }}>
      <p style={{ marginBottom: 4 }}>
        <Link to={`/content/${contentId}/edit`}>&larr; Kembali ke draft konten</Link>
      </p>
      <span className="eyebrow">Rencana Produksi</span>
      <h1>Storyboard</h1>

      {error && <p className="callout callout--error">{error}</p>}

      {!storyboard && (
        <div className="panel panel--dashed empty-state">
          Konten ini belum punya storyboard.
          <div style={{ marginTop: 12 }}>
            <button onClick={handleCreateStoryboard} className="btn btn--primary">
              + Buat Storyboard
            </button>
          </div>
        </div>
      )}

      {storyboard && (
        <div>
          <div className="btn-row" style={{ marginBottom: 16, alignItems: "center" }}>
            <span className="badge-count">{storyboard.scenes.length} SCENE</span>
            <span className="text-muted" style={{ fontFamily: "var(--font-mono)", fontSize: 13 }}>
              Total durasi: {totalDuration} detik
            </span>
          </div>

          {storyboard.scenes.length === 0 && (
            <p className="text-muted" style={{ marginBottom: 16 }}>Belum ada scene. Tambahkan di bawah.</p>
          )}

          <div className="stack" style={{ marginBottom: 24 }}>
            {storyboard.scenes.map((scene, idx) => (
              <div key={scene.id} className="panel">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <span
                    style={{
                      fontFamily: "var(--font-display)",
                      fontSize: 22,
                      background: "var(--yellow)",
                      border: "3px solid var(--ink)",
                      borderRadius: 4,
                      padding: "2px 10px",
                    }}
                  >
                    {String(idx + 1).padStart(2, "0")}
                  </span>
                  <div className="btn-row">
                    <button onClick={() => handleMove(scene.id, "up")} disabled={idx === 0} className="btn btn--sm">
                      ↑
                    </button>
                    <button
                      onClick={() => handleMove(scene.id, "down")}
                      disabled={idx === storyboard.scenes.length - 1}
                      className="btn btn--sm"
                    >
                      ↓
                    </button>
                    <button onClick={() => handleDeleteScene(scene.id)} className="btn btn--sm btn--danger">
                      Hapus
                    </button>
                  </div>
                </div>

                <label className="field">
                  <span className="field__label">Deskripsi</span>
                  <textarea
                    defaultValue={scene.description ?? ""}
                    rows={2}
                    className="textarea"
                    onBlur={(e) => handleUpdateScene(scene.id, "description", e.target.value)}
                  />
                </label>

                <label className="field" style={{ marginBottom: 8, maxWidth: 160 }}>
                  <span className="field__label">Durasi (detik)</span>
                  <input
                    type="number"
                    defaultValue={scene.durationSeconds}
                    className="input"
                    onBlur={(e) => handleUpdateScene(scene.id, "durationSeconds", e.target.value)}
                  />
                </label>

                <p className="text-muted" style={{ fontSize: 12, margin: 0 }}>
                  Upload sketsa gambar akan tersedia setelah integrasi Google Drive.
                </p>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddScene} className="panel panel--dashed">
            <span className="eyebrow">Tambah scene baru</span>
            <label className="field">
              <span className="field__label">Deskripsi</span>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                className="textarea"
              />
            </label>
            <label className="field" style={{ marginBottom: 12, maxWidth: 160 }}>
              <span className="field__label">Durasi (detik)</span>
              <input
                type="number"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="input"
              />
            </label>
            <button type="submit" disabled={isAdding} className="btn btn--primary">
              {isAdding ? "Menambah..." : "+ Tambah Scene"}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}