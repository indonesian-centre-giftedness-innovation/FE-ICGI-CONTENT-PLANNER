import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../lib/api";

export function ContentNewPage() {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [platform, setPlatform] = useState("");
  const [bodyDraft, setBodyDraft] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!title.trim()) {
      setError("Judul wajib diisi");
      return;
    }

    setIsSaving(true);
    try {
      const created = await api.createContent({
        title: title.trim(),
        platform: platform.trim() || undefined,
        bodyDraft: bodyDraft.trim() || undefined,
      });
      navigate(`/content/${created.id}/edit`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal membuat draft");
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div style={{ maxWidth: 560 }}>
      <span className="eyebrow">Langkah 1 — Ide & Draft</span>
      <h1>Draft Konten Baru</h1>

      <form onSubmit={handleSubmit} className="panel">
        <label className="field">
          <span className="field__label">Judul</span>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Misal: Promo Ramadhan 2026"
            className="input"
          />
        </label>

        <label className="field">
          <span className="field__label">Platform (opsional)</span>
          <input
            type="text"
            value={platform}
            onChange={(e) => setPlatform(e.target.value)}
            placeholder="Instagram, Website, Newsletter, dll"
            className="input"
          />
        </label>

        <label className="field">
          <span className="field__label">Draft awal (opsional, bisa di-generate AI nanti)</span>
          <textarea
            value={bodyDraft}
            onChange={(e) => setBodyDraft(e.target.value)}
            rows={6}
            className="textarea"
          />
        </label>

        {error && <p className="callout callout--error" style={{ marginBottom: 14 }}>{error}</p>}

        <div className="btn-row">
          <button type="submit" className="btn btn--primary" disabled={isSaving}>
            {isSaving ? "Menyimpan..." : "Simpan Draft"}
          </button>
          <button type="button" className="btn btn--ghost" onClick={() => navigate("/dashboard")} disabled={isSaving}>
            Batal
          </button>
        </div>
      </form>
    </div>
  );
}