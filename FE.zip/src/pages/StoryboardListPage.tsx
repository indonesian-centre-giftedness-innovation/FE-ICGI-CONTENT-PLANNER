import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, type StoryboardSummary } from "../lib/api";
import { StatusStamp } from "../components/StatusStamp";

function formatDuration(totalSeconds: number) {
  const mins = Math.floor(totalSeconds / 60);
  const secs = Math.round(totalSeconds % 60);
  if (mins === 0) return `${secs}d`;
  return `${mins}m ${secs}d`;
}

export function StoryboardListPage() {
  const [items, setItems] = useState<StoryboardSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api
      .listAllStoryboards()
      .then(setItems)
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div>
      <span className="eyebrow">Meja Redaksi</span>
      <h1 style={{ marginBottom: 6 }}>Storyboard</h1>
      <p className="text-muted" style={{ marginBottom: 24 }}>
        Semua storyboard yang sudah dibuat, lintas konten. Buka draft konten untuk membuat
        storyboard baru.
      </p>

      {isLoading && <p className="text-muted">Memuat...</p>}

      {!isLoading && items.length === 0 && (
        <div className="empty-state panel panel--dashed">
          Belum ada storyboard. Buka salah satu draft konten, lalu klik "Buka Storyboard".
        </div>
      )}

      {!isLoading && items.length > 0 && (
        <div className="table-wrap">
          <table className="dtable">
            <thead>
              <tr>
                <th>Konten</th>
                <th>Platform</th>
                <th>Status</th>
                <th>Jumlah Scene</th>
                <th>Total Durasi</th>
              </tr>
            </thead>
            <tbody>
              {items.map((sb) => (
                <tr key={sb.id}>
                  <td>
                    <Link to={`/content/${sb.contentId}/storyboard`} style={{ fontWeight: 700 }}>
                      {sb.content?.title || sb.title || "(tanpa judul)"}
                    </Link>
                  </td>
                  <td>{sb.content?.platform || "-"}</td>
                  <td>{sb.content && <StatusStamp status={sb.content.status} />}</td>
                  <td>{sb.sceneCount}</td>
                  <td className="text-muted" style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>
                    {formatDuration(sb.totalDurationSeconds)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}