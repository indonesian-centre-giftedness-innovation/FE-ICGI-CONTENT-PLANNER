import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, type Content, type ContentStatus, type CalendarItem } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { StatusStamp, STATUS_LABEL } from "../components/StatusStamp";
import { CalendarWidget } from "../components/CalendarWidget";

const STAT_ACCENT: Record<ContentStatus, string> = {
  draft: "#8a8a8f",
  pending_review: "var(--blue)",
  revisi: "var(--red)",
  approved: "var(--green)",
  published: "var(--yellow)",
};

export function DashboardPage() {
  const { user } = useAuth();
  const [allContents, setAllContents] = useState<Content[]>([]);
  const [calendarItems, setCalendarItems] = useState<CalendarItem[]>([]);
  const [contents, setContents] = useState<Content[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [search, setSearch] = useState("");

  // dipakai buat kartu ringkasan — selalu total keseluruhan, tidak ikut filter tabel
  useEffect(() => {
    api.listContents().then(setAllContents).catch(() => {});
    api.listCalendarItems().then(setCalendarItems).catch(() => {});
  }, []);

  async function loadContents() {
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.listContents({
        status: statusFilter || undefined,
        search: search || undefined,
      });
      setContents(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal memuat konten");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadContents();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    loadContents();
  }

  const statuses = Object.keys(STATUS_LABEL) as ContentStatus[];
  const countFor = (s: ContentStatus) => allContents.filter((c) => c.status === s).length;

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 12, marginBottom: 24 }}>
        <div>
          <span className="eyebrow">Meja Redaksi</span>
          <h1 style={{ marginBottom: 4 }}>Dashboard Konten</h1>
          <p className="text-muted">
            Login sebagai {user?.role === "lead_admin" ? "Lead/Admin" : "Creator/Staff"}
          </p>
        </div>
        <Link to="/content/new" className="btn btn--primary">
          + Buat Draft Baru
        </Link>
      </div>

      <div className="stat-grid">
        <div className="stat-card" style={{ ["--accent" as string]: "var(--ink)" }}>
          <div className="stat-card__value">{allContents.length}</div>
          <span className="stat-card__label">Total Konten</span>
        </div>
        {statuses.map((s) => (
          <div key={s} className="stat-card" style={{ ["--accent" as string]: STAT_ACCENT[s] }}>
            <div className="stat-card__value">{countFor(s)}</div>
            <span className="stat-card__label">{STATUS_LABEL[s]}</span>
          </div>
        ))}
      </div>

      <CalendarWidget items={calendarItems} />

      <form onSubmit={handleSearchSubmit} className="btn-row" style={{ marginBottom: 20 }}>
        <input
          type="text"
          placeholder="Cari judul konten..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="input"
          style={{ maxWidth: 260 }}
        />
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="select"
          style={{ maxWidth: 200 }}
        >
          <option value="">Semua status</option>
          {statuses.map((status) => (
            <option key={status} value={status}>
              {STATUS_LABEL[status]}
            </option>
          ))}
        </select>
        <button type="submit" className="btn">
          Cari
        </button>
      </form>

      {isLoading && <p className="text-muted">Memuat...</p>}
      {error && <p className="callout callout--error">{error}</p>}

      {!isLoading && !error && contents.length === 0 && (
        <div className="empty-state panel panel--dashed">
          Belum ada konten yang cocok. Coba ubah filter, atau mulai buat draft baru.
        </div>
      )}

      {!isLoading && contents.length > 0 && (
        <div className="table-wrap">
          <table className="dtable">
            <thead>
              <tr>
                <th>Judul</th>
                <th>Platform</th>
                <th>Status</th>
                <th>Penulis</th>
                <th>Diperbarui</th>
              </tr>
            </thead>
            <tbody>
              {contents.map((c) => (
                <tr key={c.id}>
                  <td>
                    <Link to={`/content/${c.id}/edit`} style={{ fontWeight: 700 }}>
                      {c.title}
                    </Link>
                  </td>
                  <td>{c.platform || "-"}</td>
                  <td>
                    <StatusStamp status={c.status} />
                  </td>
                  <td className="text-muted">{c.author?.name || "-"}</td>
                  <td className="text-muted" style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>
                    {new Date(c.updatedAt).toLocaleDateString("id-ID")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}