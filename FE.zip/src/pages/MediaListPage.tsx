import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, type MediaAssetSummary } from "../lib/api";

export function MediaListPage() {
  const [items, setItems] = useState<MediaAssetSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api
      .listAllMedia()
      .then(setItems)
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div>
      <span className="eyebrow">Meja Redaksi</span>
      <h1 style={{ marginBottom: 6 }}>Media &amp; Review</h1>
      <p className="text-muted" style={{ marginBottom: 24 }}>
        Semua poster/video yang sudah diunggah, lintas konten — pengganti review lewat WhatsApp.
      </p>

      {isLoading && <p className="text-muted">Memuat...</p>}

      {!isLoading && items.length === 0 && (
        <div className="empty-state panel panel--dashed">
          Belum ada media diunggah. Buka salah satu draft konten, lalu klik "Buka Media & Review".
        </div>
      )}

      {!isLoading && items.length > 0 && (
        <div className="table-wrap">
          <table className="dtable">
            <thead>
              <tr>
                <th>File</th>
                <th>Konten</th>
                <th>Status Versi Terbaru</th>
                <th>Jumlah Versi</th>
                <th>Diunggah</th>
              </tr>
            </thead>
            <tbody>
              {items.map((m) => (
                <tr key={m.id}>
                  <td style={{ fontWeight: 700 }}>{m.fileName}</td>
                  <td>
                    <Link to={`/content/${m.contentId}/media`}>
                      {m.content?.title || "(konten dihapus)"}
                    </Link>
                  </td>
                  <td>
                    {m.latestVersion ? (
                      <span
                        className="stamp"
                        style={{
                          color: m.latestVersion.status === "approved" ? "var(--green)" : "var(--blue)",
                        }}
                      >
                        {m.latestVersion.status === "approved" ? "Approved" : "Menunggu Review"}
                      </span>
                    ) : (
                      "-"
                    )}
                  </td>
                  <td>{m.versionCount}</td>
                  <td className="text-muted" style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>
                    {new Date(m.createdAt).toLocaleDateString("id-ID")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}