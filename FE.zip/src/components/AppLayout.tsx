import { useEffect, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import type { ReactNode } from "react";
import { useAuth } from "../context/AuthContext";
import { api } from "../lib/api";

function SidebarLink({
  to,
  children,
}: {
  to: string;
  children: ReactNode;
}) {
  return (
    <NavLink
      to={to}
      end={to === "/dashboard"}
      className={({ isActive }) =>
        "sidebar__link" + (isActive ? " sidebar__link--active" : "")
      }
    >
      <span>{children}</span>
    </NavLink>
  );
}

export function AppLayout({ children }: { children: ReactNode }) {
  const { user, refresh } = useAuth();
  const navigate = useNavigate();
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    api
      .listNotifications()
      .then((items) => setUnreadCount(items.filter((n) => !n.isRead).length))
      .catch(() => {});
  }, []);

  async function handleLogout() {
    try {
      await api.logout();
    } finally {
      await refresh();
      navigate("/login");
    }
  }

  const isLeadAdmin = user?.role === "lead_admin";

  return (
    <div className="page-shell">
      <aside className="sidebar">
        <Link to="/dashboard" className="sidebar__brand">
          <span className="sidebar__brand-mark">ICGI</span>
          Content Planner
        </Link>

        <nav className="sidebar__nav">
          <div className="sidebar__section">
            <span className="sidebar__section-label">Utama</span>
            <SidebarLink to="/dashboard">Dashboard</SidebarLink>
            <SidebarLink to="/content/new">+ Draft Baru</SidebarLink>
            <NavLink
              to="/notifications"
              className={({ isActive }) =>
                "sidebar__link" + (isActive ? " sidebar__link--active" : "")
              }
            >
              <span>Notifikasi</span>
              {unreadCount > 0 && <span className="badge-count">{unreadCount}</span>}
            </NavLink>
          </div>

          <div className="sidebar__section">
            <span className="sidebar__section-label">Produksi</span>
            <SidebarLink to="/storyboard">Storyboard</SidebarLink>
            <SidebarLink to="/media">Media &amp; Review</SidebarLink>
          </div>

          {isLeadAdmin && (
            <div className="sidebar__section">
              <span className="sidebar__section-label">Redaksi</span>
              <SidebarLink to="/approval">Antrian Approval</SidebarLink>
              <span className="sidebar__link sidebar__link--soon" title="Segera hadir">
                Prompt Templates
              </span>
            </div>
          )}
        </nav>

        <div className="sidebar__footer">
          <div className="sidebar__role">{isLeadAdmin ? "Lead / Admin" : "Creator / Staff"}</div>
          <button onClick={handleLogout} className="btn btn--sm btn--danger" style={{ width: "100%", marginTop: 4 }}>
            Keluar
          </button>
        </div>
      </aside>

      <main className="page-content">{children}</main>
    </div>
  );
}